// better.js

function changeStyle(style) {
    const linkElement = document.getElementById("styleSheet");
  
    if (style === "default") {
      linkElement.href = "style.css";
    } else if (style === "italic") {
      linkElement.href = "italic-style.css";
    }
  }
 
    